package com.example.onetwo;

public class AnsListBean {
    //숫자와 결과
    private String ansNum;
    private String ansResult;

    public String getAnsNum() {
        return ansNum;
    }
    public void setAnsNum(String ansNum) {
        this.ansNum = ansNum;
    }

    public String getAnsResult() {
        return ansResult;
    }
    public void setAnsResult(String ansResult) {
        this.ansResult = ansResult;
    }
}

